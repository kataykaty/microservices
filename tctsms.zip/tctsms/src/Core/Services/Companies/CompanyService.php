<?php
namespace Drupal\tctsms\Core\Services\Companies;

use Drupal\Core\Database\Database;
use Drupal\tctsms\Core\Services\Companies\CompanyService;
use Drupal\tctsms\Core\Domain\Companies\Company;

class CompanyService{
	public function search($q){
		$query = \Drupal::database()->select('mydata', 'm');
		$query->fields('m');
		if(!empty($q)){
			$db_or = db_or();
			$db_or->condition('name', '%' . $q . '%', 'LIKE');
			$db_or->condition('mobilenumber', '%' . $q . '%', 'LIKE');
			$db_or->condition('email', '%' . $q . '%', 'LIKE');
			$query->condition($db_or);
		}
		$results = $query->execute()->fetchAll();
		$rows=array();	
		foreach($results as $data){
			$company= new Company($data->id,
					$data->name,
					$data->mobilenumber,
					$data->email,
					$data->age,
					$data->gender,
					$data->website);
			
			$rows[] =$company;
		}
		return $rows;
	}
	
	
	public function getCompany($id){
		$query = \Drupal::database()->select('mydata', 'm');
		$query->fields('m');
		$query->condition('id',$id);
		$data = $query->execute()->fetchAssoc();
		$company= new Company($data['id'],
				$data['name'],
				$data['mobilenumber'],
				$data['email'],
				$data['age'],
				$data['gender'],
				$data['website']);
		return $company;
	}
	
	public function updateCompany($data){
		$field_update = array('name' => $data->name,
				'mobilenumber' => $data->mobilenumber,
				'email' => $data->email,
				'age' => $data->age,
				'gender' => $data->gender,
				'website' => $data->website);
		$query = \Drupal::database();
		$query->update('mydata')
		->fields($field_update)
		->condition('id', $data->id)
		->execute();
	}
	
	public function insertCompany($data){
		$insert = array('name' => $data->name, 
				'mobilenumber' => $data->mobilenumber, 
				'email' => $data->email, 
				'age' => $data->age, 
				'gender' => $data->gender, 
				'website' => $data->website);
		db_insert('mydata')
		->fields($insert)
		->execute();
	}
	
	public function deleteCompany($id){
		$query = \Drupal::database();
		$query->delete('mydata')
		->condition('id',$id)
		->execute();
	}
}
?>