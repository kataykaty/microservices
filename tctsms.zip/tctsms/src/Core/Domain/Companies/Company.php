<?php
namespace Drupal\tctsms\Core\Domain\Companies;

class Company{

    public $id;
	public $name;
	public $mobilenumber;
	public $email;
	public $age;
	public $gender;
	public $website;
	
	function __construct($id,$name,$mobilenumber,$email,$age,$gender,$website)
	{
		$this->id=$id;
		$this->name=$name;
		$this->mobilenumber=$mobilenumber;
		$this->email=$email;
		$this->age=$age;
		$this->gender=$gender;
		$this->website=$website;
	}
	
}
?>