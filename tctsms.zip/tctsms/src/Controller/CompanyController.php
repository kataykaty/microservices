<?php
namespace Drupal\tctsms\Controller;
use Drupal\Core\Controller\ControllerBase;
use Drupal\tctsms\Core\Domain\Companies\Company;
use Drupal\tctsms\Core\Services\Companies\CompanyService;

class CompanyController extends BaseController
{
  /**
   * 
   * @param  string $name
   * @return string
   */
  public function index() 
  {	
  	$model = NULL;
  	$companyService = new CompanyService();
  	if(isset($_GET['q']))
  		$model=$companyService->search($_GET['q']);
    return [
      '#theme' => 'company_index',
      '#model' =>$model,
    ];
  }
  
  public function add_GET()
  {
  	return ['#theme' => 'company_add_page',];
  }
  
  public function add_POST()
  {
	  	if(empty($_POST['name'])){
	  		$this->addModelState("Please enter name");	  		
	  	}
	  	if(empty($_POST['mobilenumber'])){
	  		$this->addModelState("Please enter mobile");
	  	}
	  	if(empty($_POST['age'])){
	  		$this->addModelState("Please enter age");
	  	}
	  	if(!preg_match('/^[0-9]+$/', $_POST['age']) ){
	  		$this->addModelState("Age must is number");
	  	}
	  	if(empty($_POST['email'])){
	  		$this->addModelState("Please enter email");
	  	}
	  	if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
	  		$this->addModelState("The email must be in the correct format");
	  	}
	  	
  		if($this->isValidModelState()){
  			try{
  				//TODO: use mapper function
			  	$name=$_POST['name'];
			  	$mobilenumber=$_POST['mobilenumber'];
			  	$email=$_POST['email'];
			  	$age=$_POST['age'];
			  	$gender=$_POST['gender'];
			  	$website=$_POST['website'];
			  	
			  	$instance = new CompanyService();
			  	$company=new Company(1,$name,$mobilenumber,$email,$age,$gender,$website);
			  	$instance->insertCompany($company);
			  	
			  	return $this->redirect('tctsms_company_index');
		  	}
		  	catch (Exception $e) {
		  		$this->addModelState($e);
  			}
  		}
  		drupal_set_message($this->getModelState());
		return ['#theme' => 'company_add_page',];
  }
  
  
  public function view_Company($id = NULL)
  {
  	$companyService = new CompanyService();
  	$data=$companyService->getCompany($id);
  	return [
  			'#theme' => 'company_detail_page',
  			'#detail_company' =>$data,
  	];
  }
  
  
  public function edit_Company($id=NULL)
  {
  	$companyService = new CompanyService();
  	$edit=$companyService->getCompany($id);
  	if(isset($_GET['update'])&&isset($_GET['name'])){
  		$name=$_GET['name'];
  		$mobilenumber=$_GET['mobilenumber'];
  		$email=$_GET['email'];
  		$age=$_GET['age'];
  		$gender=$_GET['gender'];
  		$website=$_GET['website'];
  		$company=new Company($id,$name,$mobilenumber,$email,$age,$gender,$website);
  		$companyService->updateCompany($company);
  		return $this->redirect('tctsms_company_index');
  	}
  	return [
  			'#theme' => 'company_edit_page',
  			'#edit_company' =>$edit,
  	];
  }
  
  public function delete_Company($id = NULL)
  {	
  	$companyService = new CompanyService();
  	$companyService->deleteCompany($id);
  	return $this->redirect('tctsms_company_index');
  }
  
}
