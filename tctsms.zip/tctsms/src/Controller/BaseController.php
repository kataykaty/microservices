<?php
namespace Drupal\tctsms\Controller;
use Drupal\Core\Controller\ControllerBase;

class BaseController extends ControllerBase
{
		public $modelState = array();
		
		public function addModelState($errorString){
			array_push($this->modelState,$errorString);
		}
		
		public function isValidModelState(){
			return count($this->modelState)==0;
		}
		
		public function getModelState(){
			return implode("; ", $this->modelState);
		}
		
		public function mapper($dest, $source){
			foreach ($source as $nameSource => $valueSource) {
				foreach ($dest as $nameDest => $valueDest) {
					if($nameSource == $nameDest) {
						$dest->{$nameDest} = $valueSource;
						break;
					}
				}
			}
			return $dest;
		}
}